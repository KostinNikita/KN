﻿


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, x, Step, fact, p, s, delta;
            int i, j, k, n;
            s = 1;
            n = 4;
            x = 12;
            a = 1;
            for (i = 1; i <= n; i++)
            {
                Step = Math.Pow(x, i);
                fact = s;
                for (k = i; k <= i; k++)
                {
                    fact = fact * k;
                }
                p = a;
                for (j = 1; j <= i - 1; j++)
                {
                    p = p * (p - 1);
                }
                s = s + p * Step / fact;
            }
            delta = s - Math.Pow(1 + x, a);
            Console.WriteLine("delta = {0:f20}", delta);
            Console.ReadKey();
        }
    }
}
