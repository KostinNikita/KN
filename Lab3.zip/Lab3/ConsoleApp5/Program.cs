﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTask
{
    class Program
    {
        #region Перменные задачи на скорость

        private double V1;
        private double V2;
        private double S;
        private double T;
        private double R;

        #endregion

        #region Переменные задачи о ладье

        private int a;
        //private int otvet;
        private int x;
        private int y;
        private int z;

        #endregion

        #region Переменные задачи о числе 

        private string value;
        private byte k;
        private byte b;
        private byte c;
        private int result;
        #endregion 
        static void Main(string[] args)
        {
            Program ex = new Program();
            ex.FirstTask();
            ex.SecondTask();
            ex.ThirdTask();
            Console.ReadLine();
        }

        private void FirstTask()
        {


            Console.WriteLine("Cкорость первого автомобиля");
            this.V1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Cкорость второго автомобиля");
            this.V2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Время");
            this.T = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Начальное растояние");
            this.S = Convert.ToDouble(Console.ReadLine());

            this.R = S - T * (V1 + V2);

            Console.WriteLine("Растояние между автомобилями состовляет: {0}", this.R);


        }
        private void SecondTask()
        {
            
            this.a = 925;
            Console.WriteLine("a = {0}", this.a);
            this.x = a / 100;
            this.y = (a / 10) % 10;
            this.z = a % 10;
            Console.WriteLine("{0}{1}{2}", x, z, y);
        }
        private void ThirdTask()
        {
        
            do
            {  
                Console.WriteLine("Введите число:");
                this.value = Console.ReadLine();
            } while (value.Length != 3);

            this.a = byte.Parse(value[0].ToString());
            this.b = byte.Parse(value[1].ToString());
            this.c = byte.Parse(value[2].ToString());

            this.result = (a * b) + (a * c) + (b * c);

            Console.WriteLine("Сумма произведения трёх цифр:{0}", this.result);
        }
    }
}