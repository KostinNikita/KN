﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            float a, x, y;
            for (a = 0.25f; a <= 1; a += 0.25f)
            {
                Console.WriteLine("a={0}", a);
                for (x = 0; x <= 4; x += 0.2f)
                {
                    y = (float)(x * Math.Pow(Math.E, x / a));
                    Console.WriteLine("x="+x+'\t'+"y="+y);
                }
                Console.WriteLine("\n");
                Console.ReadKey();
            }
        }
    }
}
