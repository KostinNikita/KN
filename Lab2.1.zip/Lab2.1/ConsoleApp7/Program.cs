﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    class Program
    {
        static void Main(string[] args)
        {
            double y, x, Sum;
            int n;
            Console.WriteLine("Введите число:");
            x = double.Parse(Console.ReadLine());
            Sum = 0;
            for (n = 1; n <= 10; n++)
            {
                Sum = Sum + n * n;
            }
            y = (Sum + Math.Sin(x)) / (x + 2);
            Console.WriteLine("y= {0:f8}", y);
            Console.ReadKey();
        }
    }
}
