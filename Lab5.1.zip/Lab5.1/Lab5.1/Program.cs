﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5._1
{
    class Program
    {
        static void Main(string[] args)
        {
            double max, min, x, y, z, F;
            x = 1;
            y = 2;
            z = 3;
            max = (x > y * z) ? x : y * z;
            min = (x < max) ? x : max;
            F = min * min / (x * x + z * z);
            Console.WriteLine(F);
            Console.ReadKey();
        }
    }
}
