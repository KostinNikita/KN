﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5._2
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            x = -1;
            y = -100;
            int N;

            if (x >= 0)
            {
                if (y >= 0)
                {
                    if (y < Math.Pow(x, 3)) N = 4;
                    else N = 1;
                }
                else N = 4;
            }
            else
            {
                if (y <= 0)
                {
                    if (y > Math.Pow(x, 3)) N = 3;
                    else N = 2;
                }
                else N = 3;
            }
            Console.WriteLine("N = {0}", N);
            Console.ReadKey();
        }
    }
}
