﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab4._2
{
    class Program
    {
        static void Main(string[] args)
        {
            double b, x, t, y;
            StreamWriter f = new StreamWriter("result.txt");
            StreamReader f1 = new StreamReader("send.txt");

            string x1 = f1.ReadLine();
            string[] x2 = f1.ReadLine().Split(' ');
            string[] x3 = f1.ReadLine().Split(' ');

            b = double.Parse(x1);
            f.WriteLine("Таблица");
            f.WriteLine("***********************************************************************");
            f.Write("*X=");
            for (int i = 0; i < 8; i++)
            {
                x = double.Parse(x2[i]);
                f.Write("{0} ", x);
            }
            f.Write("* T=");
            for (int i = 0; i < 8; i++)
            {
                t = double.Parse(x3[i]);
                f.Write("{0} ", t);
            }
            f.WriteLine("*");
            f.WriteLine("***********************************************************************");
            f.Write("*Y=");
            for (int i = 0; i < 8; i++)
            {
                x = double.Parse(x2[i]);
                t = double.Parse(x3[i]);
                y = Math.Pow(b,x*t)*Math.Cos(x-1);
                f.Write("{0:f3} ", y);
            }
            f.WriteLine("*");
            f.WriteLine("***********************************************************************");
            f.WriteLine("Составил: <Костин Никита Александович>");
            f.Close();
            f1.Close();
        }
    }
}
