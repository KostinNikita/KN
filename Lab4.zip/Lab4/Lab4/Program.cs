﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            double A = 0.86;
            int I = -12;
            float C = 999.002;
            bool L = true;
            string NAME = "Kostin";
            
        }
    }
}
