﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8._2
{
    class Program
    {
        static void Fn(double x1, double y1, double x2, double y2, double xx, double yy, double c, double c1, double c2)
        {
            c = Math.Sqrt(Math.Pow(x1 - x2, 2) + Math.Pow(y1 - y2, 2));
            Console.WriteLine("Расстояние между точками 1 и 2: {0}", c);

            c1 = Math.Sqrt(Math.Pow(x1 - xx, 2) + Math.Pow(y1 - yy, 2));
            Console.WriteLine("Расстояние между точками 1 и 3: {0}", c1);

            c2 = Math.Sqrt(Math.Pow(x2 - xx, 2) + Math.Pow(y2 - yy, 2));
            Console.WriteLine("Расстояние между точками 2 и 3: {0}", c2);

            Console.WriteLine("Максимальная длинна: {0}", Math.Max(Math.Max(c, c1), Math.Max(c, c2)));
        }

        static void Main(string[] args)
        {
            Console.Write("x1=");
            double x1 = double.Parse(Console.ReadLine());
            Console.Write("y1=");
            double y1 = double.Parse(Console.ReadLine());
            Console.Write("x2=");
            double x2 = double.Parse(Console.ReadLine());
            Console.Write("y2=");
            double y2 = double.Parse(Console.ReadLine());

            Console.Write("Любой x =");
            double xx = double.Parse(Console.ReadLine());

            Console.Write("Любой y =");
            double yy = double.Parse(Console.ReadLine());
            Fn(x1, y1, x2, y2, xx, yy, 0, 0, 0);
            Console.ReadKey();
        }
    }
}
